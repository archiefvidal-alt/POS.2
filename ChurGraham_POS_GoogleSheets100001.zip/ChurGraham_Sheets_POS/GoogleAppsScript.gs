/** ChurGraham POS -> Google Sheets backend.
 * Create a Google Sheet, open Extensions > Apps Script, paste this code, save,
 * then Deploy > New deployment > Web app. Execute as: Me. Access: Anyone.
 * WARNING: the web-app URL is a write-capable endpoint. Share it only with people
 * you trust. For sensitive/multi-user production use, add Google authentication.
 */
const SHEET_NAMES = { products: 'Products', sales: 'Sales', expenses: 'Expenses', services: 'Technical Services' };
function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'load';
  if (action !== 'load') return output_({ ok: false, error: 'Unknown action' }, e);
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const data = {};
  Object.keys(SHEET_NAMES).forEach(key => {
    const sh = getSheet_(ss, SHEET_NAMES[key]);
    data[key] = sh.getLastRow() < 2 ? [] : sh.getRange(2, 2, sh.getLastRow() - 1, 1).getValues().flat().filter(String).map(v => { try { return JSON.parse(v); } catch (_) { return null; } }).filter(Boolean);
  });
  return output_({ ok: true, data: data, updatedAt: new Date().toISOString() }, e);
}
function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (body.action !== 'save' || !body.data) throw new Error('Invalid payload');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    Object.keys(SHEET_NAMES).forEach(key => {
      const rows = Array.isArray(body.data[key]) ? body.data[key] : [];
      const sh = getSheet_(ss, SHEET_NAMES[key]);
      sh.clearContents();
      sh.getRange(1, 1, 1, 2).setValues([['Record ID', 'Record JSON']]);
      if (rows.length) {
        const values = rows.map(item => [String(item.id || ''), JSON.stringify(item)]);
        sh.getRange(2, 1, values.length, 2).setValues(values);
      }
      sh.setFrozenRows(1);
      sh.autoResizeColumns(1, 2);
    });
    return output_({ ok: true, message: 'Saved', updatedAt: new Date().toISOString() }, e);
  } catch (err) {
    return output_({ ok: false, error: String(err && err.message || err) }, e);
  }
}
function getSheet_(ss, name) { return ss.getSheetByName(name) || ss.insertSheet(name); }
function output_(obj, e) {
  const json = JSON.stringify(obj);
  const callback = e && e.parameter && e.parameter.callback;
  if (callback && /^[A-Za-z_$][0-9A-Za-z_$]*$/.test(callback)) {
    return ContentService.createTextOutput(callback + '(' + json + ');').setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}
