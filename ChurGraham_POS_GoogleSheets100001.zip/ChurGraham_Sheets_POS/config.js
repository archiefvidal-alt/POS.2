/* Google Sheets connection. Paste the deployed Google Apps Script Web App URL here.
   Leave blank until the Apps Script backend is deployed. */
window.CG_CONFIG = {
  googleSheetsUrl: ""
};
