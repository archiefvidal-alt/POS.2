/* Google Sheets sync for ChurGraham POS. localStorage remains the offline working copy. */
(function () {
  const cfg = window.CG_CONFIG || {};
  const $ = id => document.getElementById(id);
  const endpoint = String(cfg.googleSheetsUrl || '').trim();
  const setStatus = message => { const el = $('syncStatus'); if (el) el.textContent = message; };
  const account = $('syncAccount');
  let busy = false, timer = null, lastSyncAt = 0;
  if (!endpoint || !/^https:\/\/script\.google\.com\/macros\/s\//.test(endpoint)) {
    setStatus('Local only • Google Sheets not configured');
    if (account) account.textContent = 'Paste your deployed Google Apps Script Web App URL into config.js. POS records remain saved locally until configured.';
  } else {
    setStatus('Google Sheets ready');
    if (account) account.textContent = 'Google Sheets endpoint configured. Use Sync to Google Sheets to send or load data.';
  }

  function snapshot() {
    return {
      products: Array.isArray(window.products) ? window.products : [],
      sales: Array.isArray(window.sales) ? window.sales : [],
      expenses: Array.isArray(window.expenses) ? window.expenses : [],
      services: Array.isArray(window.serviceJobs) ? window.serviceJobs : []
    };
  }
  function loadRemote() {
    return new Promise((resolve, reject) => {
      const callback = 'cgSheetsCb_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
      const script = document.createElement('script');
      const timeout = setTimeout(() => { cleanup(); reject(new Error('Google Sheets read timed out. Check the Web App URL and deployment access.')); }, 20000);
      function cleanup() { clearTimeout(timeout); try { delete window[callback]; } catch (_) { window[callback] = undefined; } script.remove(); }
      window[callback] = result => { cleanup(); if (!result || !result.ok) reject(new Error(result && result.error || 'Could not read Google Sheets')); else resolve(result); };
      script.onerror = () => { cleanup(); reject(new Error('Could not reach Google Sheets. Check the Web App URL and deployment access.')); };
      script.src = endpoint + (endpoint.includes('?') ? '&' : '?') + 'action=load&callback=' + callback + '&t=' + Date.now();
      document.head.appendChild(script);
    });
  }
  async function pushRemote(data) {
    // Apps Script does not handle browser preflight requests. text/plain + no-cors sends the POST without preflight.
    await fetch(endpoint, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ action: 'save', data }) });
    // Verify that the endpoint can be read after writing; Apps Script processing may take a moment.
    await new Promise(resolve => setTimeout(resolve, 1200));
    return loadRemote();
  }
  function applyRemote(data) {
    if (!data || typeof data !== 'object') throw new Error('The sheet returned invalid data.');
    const next = {
      products: Array.isArray(data.products) ? data.products : [],
      sales: Array.isArray(data.sales) ? data.sales : [],
      expenses: Array.isArray(data.expenses) ? data.expenses : [],
      services: Array.isArray(data.services) ? data.services : []
    };
    // Do not replace local data with an empty sheet on first connection.
    const local = snapshot();
    const localCount = local.products.length + local.sales.length + local.expenses.length + local.services.length;
    const remoteCount = next.products.length + next.sales.length + next.expenses.length + next.services.length;
    if (remoteCount === 0 && localCount > 0) {
      throw new Error('Google Sheets is empty, but this device has records. Syncing was stopped to protect local data. Export a backup first, then choose Upload Local Data.');
    }
    window.products = next.products;
    window.sales = next.sales;
    window.expenses = next.expenses;
    window.serviceJobs = next.services;
    save(KEYS.products, window.products); save(KEYS.sales, window.sales); save(KEYS.expenses, window.expenses); save(KEYS.services, window.serviceJobs);
    if (typeof renderAll === 'function') renderAll();
  }
  async function sync(mode) {
    if (!endpoint) { if (typeof showToast === 'function') showToast('Add Google Sheets URL in config.js first.'); return; }
    if (busy) return;
    busy = true; setStatus('Connecting to Google Sheets…');
    try {
      if (mode === 'upload') {
        await pushRemote(snapshot());
      } else {
        const result = await loadRemote();
        const remote = result.data || {};
        const local = snapshot();
        const localCount = local.products.length + local.sales.length + local.expenses.length + local.services.length;
        const remoteCount = ['products','sales','expenses','services'].reduce((n,k)=>n+(Array.isArray(remote[k])?remote[k].length:0),0);
        if (remoteCount === 0 && localCount > 0) {
          const choose = confirm('Google Sheets is empty and this device has existing records. Press OK to upload this device’s records to Google Sheets. Press Cancel to leave both unchanged. Export a backup first if you have not already.');
          if (!choose) { setStatus('Sync cancelled • local data preserved'); return; }
          await pushRemote(local);
        } else if (remoteCount > 0) {
          const choice = confirm('Google Sheets has ' + remoteCount + ' records. Press OK to LOAD the Google Sheets data onto this device (replaces this device’s current lists). Press Cancel to keep this device’s data and UPLOAD it to Google Sheets instead. Export a backup before continuing.');
          if (choice) applyRemote(remote); else await pushRemote(local);
        } else {
          await pushRemote(local);
        }
      }
      lastSyncAt = Date.now(); setStatus('Google Sheets sync checked • ' + new Date().toLocaleTimeString());
      if (account) account.textContent = 'Last sync attempt: ' + new Date().toLocaleString() + '. Keep using Export Backup as a safety copy.';
      if (typeof showToast === 'function') showToast('Google Sheets sync finished.');
    } catch (err) {
      console.error(err); setStatus('Sheets sync issue • local data safe');
      if (account) account.textContent = (err && err.message || 'Sync failed') + ' Local data has been kept on this device.';
      if (typeof showToast === 'function') showToast('Sheets sync issue. Local data is safe.');
    } finally { busy = false; }
  }
  const syncButton = $('syncNow'); if (syncButton) syncButton.onclick = () => sync('check');
  // After local saves, upload only if the endpoint is configured. Debounce repeated changes.
  if (endpoint && typeof window.save === 'function') {
    const baseSave = window.save;
    window.save = function (key, data) {
      baseSave(key, data);
      clearTimeout(timer);
      timer = setTimeout(() => sync('upload'), 2500);
    };
  }
  window.addEventListener('online', () => { if (endpoint && Date.now() - lastSyncAt > 10000) sync('check'); });
})();
