/* ChurGraham POS - Beginner-friendly JavaScript
   Data is saved in localStorage so the POS can work offline. */

const KEYS = {
  products: "churgraham_products",
  sales: "churgraham_sales",
  expenses: "churgraham_expenses",
  services: "churgraham_services",
};

const defaultProducts = [
  {id:"p1", name:"Classic Churros", category:"Churros", price:30, stock:50, cost:15, image:""},
  {id:"p2", name:"Churros with Chocolate Syrup", category:"Churros", price:35, stock:50, cost:18, image:""},
  {id:"p3", name:"Mango Graham Bar", category:"Graham Bar", price:35, stock:50, cost:18, image:""},
  {id:"p4", name:"Cookies and Cream Graham Bar", category:"Graham Bar", price:35, stock:50, cost:18, image:""}
];

var products = load(KEYS.products, defaultProducts);
var sales = load(KEYS.sales, []);
var expenses = load(KEYS.expenses, []);
var serviceJobs = load(KEYS.services, []);
let cart = [];
let selectedCategory = "All";
let currentImage = "";

function load(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : JSON.parse(JSON.stringify(fallback));
  } catch (e) { return JSON.parse(JSON.stringify(fallback)); }
}
function save(key, data) { localStorage.setItem(key, JSON.stringify(data)); }
function money(n) { return "₱" + Number(n || 0).toLocaleString("en-PH",{minimumFractionDigits:2,maximumFractionDigits:2}); }
function today() { return new Date().toISOString().slice(0,10); }
function escapeHTML(str) {
  return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
function getProduct(id){ return products.find(p=>p.id===id); }
function getOrderNumber(){ return sales.length ? Math.max(...sales.map(s=>Number(s.orderNumber)||0))+1 : 1; }
function showToast(message) {
  const el=document.getElementById("toast"); el.textContent=message; el.classList.add("show");
  setTimeout(()=>el.classList.remove("show"),2200);
}
function dateTimeNow(){
  const d=new Date();
  return {date:d.toISOString().slice(0,10),time:d.toLocaleTimeString("en-PH",{hour:"2-digit",minute:"2-digit"})};
}

/* Navigation */
const pageTitles = {dashboard:"Dashboard",pos:"POS / New Sale",products:"Products",inventory:"Inventory",sales:"Sales",reports:"Reports",income:"Income Statement",services:"Technical Services",settings:"Settings"};
function goPage(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  document.getElementById("page-"+page).classList.add("active");
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  document.getElementById("pageTitle").textContent=pageTitles[page]||page;
  document.getElementById("sidebar").classList.remove("open");
  renderAll();
}
document.querySelectorAll(".nav-btn").forEach(btn=>btn.addEventListener("click",()=>goPage(btn.dataset.page)));
document.querySelectorAll("[data-go]").forEach(btn=>btn.addEventListener("click",()=>goPage(btn.dataset.go)));
document.getElementById("headerSaleBtn").onclick=()=>goPage("pos");
document.getElementById("menuBtn").onclick=()=>document.getElementById("sidebar").classList.toggle("open");
document.getElementById("currentDate").textContent=new Date().toLocaleDateString("en-PH",{weekday:"long",year:"numeric",month:"long",day:"numeric"});

/* POS product display */
function renderPOSProducts(){
  const q=document.getElementById("productSearch").value.toLowerCase();
  const list=products.filter(p=>(selectedCategory==="All"||p.category===selectedCategory)&&p.name.toLowerCase().includes(q));
  const box=document.getElementById("posProducts");
  box.innerHTML=list.length ? list.map(p=>`
    <button class="product-card ${p.stock<=0?"out":""}" onclick="addToCart('${p.id}')">
      <div class="product-img">${p.image?`<img src="${p.image}" alt="">`:p.category==="Churros"?"🍩":"🍰"}</div>
      <div class="product-info">
        <h4>${escapeHTML(p.name)}</h4><p>${escapeHTML(p.category)} • ${p.stock} stock</p>
        <span class="price">${money(p.price)}</span>
      </div>
    </button>`).join("") : `<div class="empty">No products found.</div>`;
}
document.getElementById("productSearch").addEventListener("input",renderPOSProducts);
document.querySelectorAll(".category").forEach(btn=>btn.addEventListener("click",()=>{
  selectedCategory=btn.dataset.category;
  document.querySelectorAll(".category").forEach(b=>b.classList.toggle("active",b===btn));
  renderPOSProducts();
}));

/* Cart */
function addToCart(id){
  const p=getProduct(id);
  if(!p||p.stock<=0){showToast("Product is out of stock.");return;}
  const item=cart.find(x=>x.id===id);
  if(item){
    if(item.qty>=p.stock){showToast("Not enough stock.");return;}
    item.qty++;
  } else cart.push({id,qty:1});
  renderCart();
}
function changeQty(id,delta){
  const item=cart.find(x=>x.id===id), p=getProduct(id);
  if(!item||!p)return;
  const newQty=item.qty+delta;
  if(newQty<=0) cart=cart.filter(x=>x.id!==id);
  else if(newQty<=p.stock)item.qty=newQty;
  else showToast("Not enough stock.");
  renderCart();
}
function removeCart(id){cart=cart.filter(x=>x.id!==id);renderCart();}
function clearCart(){if(cart.length&&!confirm("Clear the current order?"))return;cart=[];document.getElementById("discountInput").value=0;document.getElementById("cashInput").value="";renderCart();}
document.getElementById("clearCart").onclick=clearCart;

function getSubtotal(){return cart.reduce((sum,i)=>sum+(getProduct(i.id)?.price||0)*i.qty,0);}
function getDiscount(){return Math.min(Math.max(Number(document.getElementById("discountInput").value)||0,0),getSubtotal());}
function getTotal(){return Math.max(0,getSubtotal()-getDiscount());}
function renderCart(){
  const box=document.getElementById("cartItems");
  document.getElementById("orderNumberLabel").textContent="Order #"+getOrderNumber();
  if(!cart.length) box.innerHTML=`<div class="empty">🛒<br><br>Your cart is empty.<br>Add products to start a sale.</div>`;
  else box.innerHTML=cart.map(i=>{
    const p=getProduct(i.id), sub=p.price*i.qty;
    return `<div class="cart-item"><div><h4>${escapeHTML(p.name)}</h4><span class="unit">${money(p.price)} each</span>
      <div class="cart-actions"><button class="qty-btn" onclick="changeQty('${p.id}',-1)">−</button><strong>${i.qty}</strong><button class="qty-btn" onclick="changeQty('${p.id}',1)">+</button><button class="remove" onclick="removeCart('${p.id}')">Remove</button></div></div><strong>${money(sub)}</strong></div>`;
  }).join("");
  document.getElementById("cartSubtotal").textContent=money(getSubtotal());
  document.getElementById("cartTotal").textContent=money(getTotal());
  updateChange();
}
function updateChange(){
  const cash=Number(document.getElementById("cashInput").value)||0, total=getTotal();
  document.getElementById("changeAmount").textContent=money(Math.max(0,cash-total));
}
document.getElementById("discountInput").addEventListener("input",renderCart);
document.getElementById("cashInput").addEventListener("input",updateChange);

/* Checkout and receipt */
document.getElementById("completeSale").onclick=()=>{
  if(!cart.length){showToast("Add a product first.");return;}
  const total=getTotal(), cash=Number(document.getElementById("cashInput").value)||0;
  if(cash<total){showToast("Cash received is less than the total.");return;}
  for(const i of cart){const p=getProduct(i.id);if(!p||p.stock<i.qty){showToast("Stock changed. Please review the cart.");return;}}
  const dt=dateTimeNow();
  const sale={id:"s"+Date.now(),orderNumber:getOrderNumber(),date:dt.date,time:dt.time,
    items:cart.map(i=>{const p=getProduct(i.id);return {id:p.id,name:p.name,qty:i.qty,price:p.price,cost:Number(p.cost)||0};}),
    subtotal:getSubtotal(),discount:getDiscount(),total,cash,change:cash-total,payment:document.getElementById("paymentMethod").value};
  sale.items.forEach(i=>{const p=getProduct(i.id);p.stock-=i.qty;});
  sales.unshift(sale);save(KEYS.sales,sales);save(KEYS.products,products);
  showReceipt(sale);cart=[];document.getElementById("cashInput").value="";document.getElementById("discountInput").value=0;renderAll();
};

function showReceipt(sale){
  document.getElementById("receiptContent").innerHTML=`<div class="receipt">
    <h2>ChurGraham</h2><div class="center">Churros & Graham Bar</div>
    <hr><div class="receipt-line"><span>Order #</span><span>${sale.orderNumber}</span></div>
    <div class="receipt-line"><span>Date</span><span>${sale.date}</span></div>
    <div class="receipt-line"><span>Time</span><span>${sale.time}</span></div><hr>
    ${sale.items.map(i=>`<div class="receipt-line"><span>${escapeHTML(i.name)} x${i.qty}</span><span>${money(i.price*i.qty)}</span></div>`).join("")}
    <hr><div class="receipt-line"><span>Subtotal</span><span>${money(sale.subtotal)}</span></div>
    <div class="receipt-line"><span>Discount</span><span>- ${money(sale.discount)}</span></div>
    <div class="receipt-line"><strong>Total</strong><strong>${money(sale.total)}</strong></div>
    <div class="receipt-line"><span>Cash</span><span>${money(sale.cash)}</span></div>
    <div class="receipt-line"><span>Change</span><span>${money(sale.change)}</span></div>
    <div class="center" style="margin-top:18px">Payment: ${escapeHTML(sale.payment)}<br><br>Thank you for ordering!</div>
  </div>`;
  document.getElementById("receiptModal").classList.add("show");
}
document.getElementById("printReceipt").onclick=()=>window.print();
document.getElementById("newSaleBtn").onclick=()=>{document.getElementById("receiptModal").classList.remove("show");goPage("pos");};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>document.getElementById(b.dataset.close).classList.remove("show"));

/* Product Management */
document.getElementById("addProductBtn").onclick=()=>openProductModal();
function openProductModal(id=null){
  currentImage="";
  document.getElementById("productForm").reset();
  document.getElementById("productId").value="";
  document.getElementById("imagePreview").innerHTML="";
  document.getElementById("productModalTitle").textContent=id?"Edit Product":"Add Product";
  if(id){const p=getProduct(id);document.getElementById("productId").value=p.id;document.getElementById("productName").value=p.name;document.getElementById("productCategory").value=p.category;document.getElementById("productPrice").value=p.price;document.getElementById("productStock").value=p.stock;currentImage=p.image||"";if(currentImage)document.getElementById("imagePreview").innerHTML=`<img src="${currentImage}">`;}
  document.getElementById("productModal").classList.add("show");
}
document.getElementById("productImage").addEventListener("change",e=>{
  const file=e.target.files[0];if(!file)return;
  const reader=new FileReader();reader.onload=()=>{currentImage=reader.result;document.getElementById("imagePreview").innerHTML=`<img src="${currentImage}">`;};reader.readAsDataURL(file);
});
document.getElementById("productForm").onsubmit=e=>{
  e.preventDefault();
  const id=document.getElementById("productId").value||"p"+Date.now();
  const old=getProduct(id);
  const product={id,name:document.getElementById("productName").value.trim(),category:document.getElementById("productCategory").value,
    price:Number(document.getElementById("productPrice").value),cost:Number(old?.cost)||0,stock:Number(document.getElementById("productStock").value),image:currentImage};
  if(!product.name||!Number.isFinite(product.price)||product.price<0||!Number.isFinite(product.stock)||product.stock<0){showToast("Please enter valid product details.");return;}
  const index=products.findIndex(p=>p.id===id);if(index>=0)products[index]=product;else products.push(product);
  save(KEYS.products,products);document.getElementById("productModal").classList.remove("show");showToast("Product saved.");renderAll();
};
function editProduct(id){openProductModal(id);}
function deleteProduct(id){if(!confirm("Delete this product?"))return;products=products.filter(p=>p.id!==id);save(KEYS.products,products);renderAll();showToast("Product deleted.");}

/* Inventory */
function stockStatus(stock){if(stock<=0)return ["Out of Stock","red"];if(stock<=10)return ["Low Stock","yellow"];return ["In Stock","green"];}
function updateStock(id){
  const input=document.getElementById("stock-"+id), value=Math.floor(Number(input.value));
  if(!Number.isFinite(value)||value<0){showToast("Invalid stock.");return;}
  const product=getProduct(id);
  if(!product){showToast("Product not found.");return;}
  const previous=Math.max(0,Number(product.stock)||0), added=value-previous;
  if(added>0){
    const raw=prompt(`You are adding ${added} units of ${product.name}. Enter the TOTAL cost of this new batch (₱). Enter 0 if there was no new cost:`);
    if(raw===null){showToast("Restock cancelled.");return;}
    const batchCost=Number(raw);
    if(!Number.isFinite(batchCost)||batchCost<0){showToast("Invalid restock cost.");return;}
    const oldCost=Math.max(0,Number(product.cost)||0);
    product.cost=value>0?((previous*oldCost)+(added*0+batchCost))/value:0;
    expenses.unshift({id:"e"+Date.now(),name:`Restock: ${product.name} (+${added} units)`,amount:batchCost,date:today(),type:"restock",productId:product.id,quantity:added,batchCost});
    save(KEYS.expenses,expenses);
  }
  product.stock=value;save(KEYS.products,products);renderAll();
  showToast(added>0?"Stock and restock cost saved.":"Stock updated.");
}

/* Sales */
function filteredSales(){
  const q=document.getElementById("salesSearch").value.toLowerCase(), d=document.getElementById("salesDate").value;
  return sales.filter(s=>(!d||s.date===d)&&(!q||String(s.orderNumber).includes(q)||s.items.some(i=>i.name.toLowerCase().includes(q))));
}
document.getElementById("salesSearch").addEventListener("input",renderSales);
document.getElementById("salesDate").addEventListener("change",renderSales);
function renderSales(){
  const list=filteredSales(), box=document.getElementById("salesTable");
  box.innerHTML=list.length?list.map(s=>`<tr><td><strong>#${s.orderNumber}</strong></td><td>${s.date}</td><td>${s.time}</td><td>${s.items.map(i=>escapeHTML(i.name)+" ×"+i.qty).join(", ")}</td><td>${money(s.total)}</td><td>${money(s.cash)}</td><td>${money(s.change)}</td><td>${escapeHTML(s.payment)}</td><td><button class="table-action" onclick="viewSale('${s.id}')">View</button> <button class="table-action delete" onclick="deleteSale('${s.id}')">Delete</button></td></tr>`).join(""):`<tr><td colspan="9" class="empty">No sales records found.</td></tr>`;
}
function viewSale(id){const s=sales.find(x=>x.id===id);if(s)showReceipt(s);}
function deleteSale(id){
  if(!confirm("Delete this sale record? Inventory will NOT be restored automatically."))return;
  sales=sales.filter(s=>s.id!==id);save(KEYS.sales,sales);renderAll();showToast("Sale deleted.");
}

/* Reports */
function inLastDays(dateStr,days){
  const d=new Date(dateStr+"T00:00:00"), now=new Date();now.setHours(0,0,0,0);
  const diff=(now-d)/86400000;return diff>=0&&diff<days;
}
function sumSales(list){return list.reduce((a,s)=>a+s.total,0);}
function renderReports(){
  const daily=sales.filter(s=>s.date===today()), weekly=sales.filter(s=>inLastDays(s.date,7)), monthly=sales.filter(s=>inLastDays(s.date,30));
  document.getElementById("reportDaily").textContent=money(sumSales(daily));document.getElementById("reportWeekly").textContent=money(sumSales(weekly));document.getElementById("reportMonthly").textContent=money(sumSales(monthly));document.getElementById("reportRevenue").textContent=money(sumSales(sales));
  const map={};sales.forEach(s=>s.items.forEach(i=>map[i.name]=(map[i.name]||0)+i.qty));
  const best=Object.entries(map).sort((a,b)=>b[1]-a[1]);
  document.getElementById("bestProducts").innerHTML=best.length?best.slice(0,8).map((x,i)=>`<div class="rank-row"><span class="rank">#${i+1}</span><span>${escapeHTML(x[0])}</span><strong>${x[1]} sold</strong></div>`).join(""):`<div class="empty">No sales yet.</div>`;
  const days=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const ds=d.toISOString().slice(0,10);days.push({label:d.toLocaleDateString("en-PH",{weekday:"short"}),value:sumSales(sales.filter(s=>s.date===ds))});}
  const max=Math.max(...days.map(d=>d.value),1);
  document.getElementById("salesChart").innerHTML=days.map(d=>`<div class="bar-wrap"><span class="bar-value">${money(d.value)}</span><div class="bar" style="height:${Math.max(3,d.value/max*190)}px"></div><span class="bar-label">${d.label}</span></div>`).join("");
}

/* Income Statement: restock costs are tracked as inventory purchases; COGS is recognized when sold. */
function renderIncome(){
  const from=document.getElementById("incomeFrom")?.value||"", to=document.getElementById("incomeTo")?.value||"";
  const inRange=d=>(!from||d>=from)&&(!to||d<=to);
  const periodSales=sales.filter(s=>inRange(s.date));
  const periodServices=serviceJobs.filter(j=>inRange(j.date)&&j.status!="Cancelled"&&(j.status==="Completed"||j.paymentStatus==="Paid"));
  const periodExpenses=expenses.filter(e=>inRange(e.date));
  const foodRevenue=periodSales.reduce((sum,s)=>sum+(Number(s.total)||0),0);
  const serviceRevenue=periodServices.reduce((sum,j)=>sum+(Number(j.charge)||0),0);
  const revenue=foodRevenue+serviceRevenue;
  const foodCogs=periodSales.reduce((sum,s)=>sum+(s.items||[]).reduce((a,i)=>a+(Number(i.cost)||0)*(Number(i.qty)||0),0),0);
  const serviceCogs=periodServices.reduce((sum,j)=>sum+(Number(j.partsCost)||0),0);
  const cogs=foodCogs+serviceCogs;
  const gross=revenue-cogs;
  const operatingExpenses=periodExpenses.filter(e=>e.type!=="restock").reduce((sum,e)=>sum+(Number(e.amount)||0),0);
  const net=gross-operatingExpenses;
  document.getElementById("stmtRevenue").textContent=money(revenue);
  document.getElementById("stmtCogs").textContent=money(cogs);
  document.getElementById("stmtGross").textContent=money(gross);
  document.getElementById("stmtExpenses").textContent=money(operatingExpenses);
  document.getElementById("stmtNet").textContent=money(net);
  document.getElementById("incomeExpenses").textContent=money(operatingExpenses);
  document.getElementById("expenseList").innerHTML=periodExpenses.length?periodExpenses.map(e=>`<div class="expense-row"><div><strong>${escapeHTML(e.name)}</strong><div class="muted">${e.date}${e.type==="restock"?" • Inventory purchase":" • Operating expense"}</div></div><div><strong>${money(e.amount)}</strong> <button onclick="deleteExpense('${e.id}')">Delete</button></div></div>`).join(""):`<div class="empty">No operating expenses added.</div>`;
}
document.getElementById("incomeFrom").addEventListener("change",renderIncome);
document.getElementById("incomeTo").addEventListener("change",renderIncome);
document.getElementById("clearIncomeDates").onclick=()=>{document.getElementById("incomeFrom").value="";document.getElementById("incomeTo").value="";renderIncome();};
document.getElementById("addExpenseBtn").onclick=()=>{
  const name=prompt("Expense name (e.g. electricity, transport, rent):");if(!name)return;
  const raw=prompt("Amount (₱):");if(raw===null)return;
  const amount=Number(raw);if(!Number.isFinite(amount)||amount<0){showToast("Invalid amount.");return;}
  expenses.unshift({id:"e"+Date.now(),name:name.trim(),amount,date:today(),type:"operating"});save(KEYS.expenses,expenses);renderIncome();showToast("Expense added.");
};
function deleteExpense(id){if(!confirm("Delete this expense?"))return;expenses=expenses.filter(e=>e.id!==id);save(KEYS.expenses,expenses);renderIncome();}

/* Technical Services */
function nextServiceNumber(){return serviceJobs.length?Math.max(...serviceJobs.map(j=>Number(j.jobNumber)||0))+1:1;}
function openServiceModal(id=null){
  const form=document.getElementById("serviceForm");form.reset();document.getElementById("serviceId").value="";document.getElementById("servicePaid").value="0";document.getElementById("servicePartsCost").value="0";document.getElementById("serviceStatus").value="Pending";document.getElementById("servicePayment").value="Unpaid";
  document.getElementById("serviceModalTitle").textContent=id?"Edit Repair Job":"New Repair Job";
  if(id){const j=serviceJobs.find(x=>x.id===id);if(!j)return;document.getElementById("serviceId").value=j.id;document.getElementById("serviceCustomer").value=j.customer||"";document.getElementById("serviceContact").value=j.contact||"";document.getElementById("serviceDevice").value=j.device||"Android Phone";document.getElementById("serviceModel").value=j.model||"";document.getElementById("serviceType").value=j.serviceType||"Other Repair";document.getElementById("serviceIssue").value=j.issue||"";document.getElementById("serviceCharge").value=j.charge||0;document.getElementById("servicePartsCost").value=j.partsCost||0;document.getElementById("serviceStatus").value=j.status||"Pending";document.getElementById("servicePayment").value=j.paymentStatus||"Unpaid";document.getElementById("servicePaid").value=j.paid||0;}
  document.getElementById("serviceModal").classList.add("show");
}
document.getElementById("addServiceBtn").onclick=()=>openServiceModal();
document.getElementById("serviceForm").onsubmit=e=>{
  e.preventDefault();const id=document.getElementById("serviceId").value||"job"+Date.now();const old=serviceJobs.find(j=>j.id===id);const charge=Number(document.getElementById("serviceCharge").value),partsCost=Number(document.getElementById("servicePartsCost").value),paid=Number(document.getElementById("servicePaid").value);
  if(!Number.isFinite(charge)||charge<0||!Number.isFinite(partsCost)||partsCost<0||!Number.isFinite(paid)||paid<0||paid>charge){showToast("Check charge, parts cost, and amount paid.");return;}
  const job={id,jobNumber:old?.jobNumber||nextServiceNumber(),date:old?.date||today(),customer:document.getElementById("serviceCustomer").value.trim(),contact:document.getElementById("serviceContact").value.trim(),device:document.getElementById("serviceDevice").value,model:document.getElementById("serviceModel").value.trim(),serviceType:document.getElementById("serviceType").value,issue:document.getElementById("serviceIssue").value.trim(),charge,partsCost,status:document.getElementById("serviceStatus").value,paymentStatus:document.getElementById("servicePayment").value,paid};
  if(job.paymentStatus==="Paid"&&paid<charge){showToast("For Paid status, amount paid must equal the charge.");return;}if(job.paymentStatus==="Unpaid"&&paid>0){showToast("Choose Partially Paid or Paid when payment has been received.");return;}
  if(old)serviceJobs=serviceJobs.map(j=>j.id===id?job:j);else serviceJobs.unshift(job);save(KEYS.services,serviceJobs);document.getElementById("serviceModal").classList.remove("show");renderAll();showToast("Repair job saved.");
};
function renderServices(){
  const active=serviceJobs.filter(j=>!["Completed","Cancelled"].includes(j.status));document.getElementById("serviceOpen").textContent=active.length;document.getElementById("serviceReady").textContent=serviceJobs.filter(j=>j.status==="Ready for Pickup").length;
  const completed=serviceJobs.filter(j=>j.status==="Completed");document.getElementById("serviceRevenue").textContent=money(completed.reduce((a,j)=>a+(Number(j.charge)||0),0));document.getElementById("serviceProfit").textContent=money(completed.reduce((a,j)=>a+(Number(j.charge)||0)-(Number(j.partsCost)||0),0));
  const body=document.getElementById("servicesTable");body.innerHTML=serviceJobs.length?serviceJobs.map(j=>`<tr><td><strong>#${j.jobNumber}</strong></td><td>${escapeHTML(j.date)}</td><td>${escapeHTML(j.customer)}<div class="muted">${escapeHTML(j.contact||"")}</div></td><td>${escapeHTML(j.device)}<div class="muted">${escapeHTML(j.model)}</div></td><td>${escapeHTML(j.serviceType)}<div class="muted">${escapeHTML(j.issue)}</div></td><td>${money(j.charge)}</td><td>${money(j.partsCost)}</td><td><span class="badge ${j.status==="Completed"?"green":j.status==="Ready for Pickup"?"yellow":"red"}">${escapeHTML(j.status)}</span></td><td>${escapeHTML(j.paymentStatus)}<div class="muted">Paid ${money(j.paid)}</div></td><td><button class="table-action" onclick="editService('${j.id}')">Edit</button> <button class="table-action delete" onclick="deleteService('${j.id}')">Delete</button></td></tr>`).join(""):`<tr><td colspan="10" class="empty">No repair jobs yet. Tap “New Repair Job” to get started.</td></tr>`;
}
function editService(id){openServiceModal(id);}
function deleteService(id){if(!confirm("Delete this repair job? This cannot be undone unless you have a backup."))return;serviceJobs=serviceJobs.filter(j=>j.id!==id);save(KEYS.services,serviceJobs);renderAll();showToast("Repair job deleted.");}

/* Dashboard and inventory */
function renderDashboard(){
  const d=sales.filter(s=>s.date===today()), revenue=sumSales(d), items=d.reduce((a,s)=>a+s.items.reduce((x,i)=>x+i.qty,0),0), profit=sumSales(sales)-sales.reduce((a,s)=>a+(s.items||[]).reduce((x,i)=>x+(Number(i.cost)||0)*(Number(i.qty)||0),0),0)-expenses.filter(e=>e.type!=="restock").reduce((a,e)=>a+(Number(e.amount)||0),0);
  document.getElementById("dashSales").textContent=money(revenue);document.getElementById("dashOrders").textContent=d.length;document.getElementById("dashItems").textContent=items;document.getElementById("dashProfit").textContent=money(profit);
  document.getElementById("recentSales").innerHTML=d.slice(0,5).length?d.slice(0,5).map(s=>`<div class="sale-row"><div><strong>Order #${s.orderNumber}</strong><div class="muted">${s.time} • ${s.items.reduce((a,i)=>a+i.qty,0)} items</div></div><span class="amount">${money(s.total)}</span></div>`).join(""):`<div class="empty">No sales today.</div>`;
  const alerts=products.filter(p=>p.stock<=10);
  document.getElementById("inventoryAlerts").innerHTML=alerts.length?alerts.map(p=>{const [st,cl]=stockStatus(p.stock);return `<div class="alert-row"><span>${escapeHTML(p.name)}</span><span class="badge ${cl}">${st} (${p.stock})</span></div>`}).join(""):`<div class="empty">All products have healthy stock.</div>`;
}
function renderProducts(){
  document.getElementById("productsTable").innerHTML=products.map(p=>`<tr><td><strong>${escapeHTML(p.name)}</strong></td><td>${escapeHTML(p.category)}</td><td>${money(p.price)}</td><td>${p.stock}</td><td><button class="table-action" onclick="editProduct('${p.id}')">Edit</button> <button class="table-action delete" onclick="deleteProduct('${p.id}')">Delete</button></td></tr>`).join("");
}
function renderInventory(){
  const low=products.filter(p=>p.stock>0&&p.stock<=10).length,out=products.filter(p=>p.stock<=0).length;
  document.getElementById("invProducts").textContent=products.length;document.getElementById("invStock").textContent=products.reduce((a,p)=>a+p.stock,0);document.getElementById("invLow").textContent=low;document.getElementById("invOut").textContent=out;
  document.getElementById("inventoryTable").innerHTML=products.map(p=>{const [st,cl]=stockStatus(p.stock);return `<tr><td><strong>${escapeHTML(p.name)}</strong></td><td>${escapeHTML(p.category)}</td><td>${money(p.price)}</td><td><input id="stock-${p.id}" type="number" min="0" value="${p.stock}" style="width:90px;margin:0"></td><td><span class="badge ${cl}">${st}</span></td><td><button class="table-action" onclick="updateStock('${p.id}')">Save Stock</button></td></tr>`}).join("");
}

/* Backup */
document.getElementById("exportData").onclick=()=>{
  const data={products,sales,expenses,serviceJobs,exportedAt:new Date().toISOString()};
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download="churgraham-pos-backup.json";a.click();URL.revokeObjectURL(url);showToast("Backup exported.");
};
document.getElementById("importData").onchange=e=>{
  const file=e.target.files[0];if(!file)return;const reader=new FileReader();
  reader.onload=()=>{try{const d=JSON.parse(reader.result);if(!Array.isArray(d.products)||!Array.isArray(d.sales)||!Array.isArray(d.expenses))throw Error();
    products=d.products.map(p=>({...p,cost:Number(p.cost)||0}));sales=d.sales;expenses=d.expenses;serviceJobs=Array.isArray(d.serviceJobs)?d.serviceJobs:[];save(KEYS.products,products);save(KEYS.sales,sales);save(KEYS.expenses,expenses);save(KEYS.services,serviceJobs);renderAll();showToast("Backup imported.");}catch(err){showToast("Invalid backup file.");}};reader.readAsText(file);
};
document.getElementById("resetData").onclick=()=>{
  if(!confirm("Reset ALL ChurGraham data? This also deletes your cloud copy if cloud sync is on, and cannot be undone unless you have a backup."))return;
  localStorage.removeItem(KEYS.products);localStorage.removeItem(KEYS.sales);localStorage.removeItem(KEYS.expenses);localStorage.removeItem(KEYS.services);
  products=JSON.parse(JSON.stringify(defaultProducts));sales=[];expenses=[];serviceJobs=[];cart=[];save(KEYS.products,products);save(KEYS.sales,sales);save(KEYS.expenses,expenses);save(KEYS.services,serviceJobs);renderAll();showToast("Data reset.");
};

function renderAll(){renderPOSProducts();renderCart();renderProducts();renderInventory();renderSales();renderReports();renderIncome();renderServices();renderDashboard();}
renderAll();
